#!/usr/bin/env bash
set -euo pipefail
SRC=/d/VidoByte/BuildTools/Sources/ffmpeg-9.0.2
BASE=/d/VidoByte/StoreMF/FFmpegCustom
mkdir -p "$BASE/build" "$BASE/install"
cd "$BASE/build"
"$SRC/configure" \
 --prefix="$BASE/install" \
 --arch=x86_64 --target-os=mingw32 \
 --disable-gpl --disable-nonfree --enable-version3 \
 --disable-libopenh264 --disable-libx264 --disable-libx265 \
 --disable-autodetect \
 --enable-libsvtav1 --enable-libdav1d --enable-mediafoundation --enable-d3d11va \
 --disable-ffplay --disable-doc --disable-debug \
 --enable-static --disable-shared \
 > "$BASE/configure.log" 2>&1
echo "CONFIGURE_PASS"
make -j4 > "$BASE/make.log" 2>&1
echo "MAKE_PASS"
make install > "$BASE/install.log" 2>&1
echo "INSTALL_PASS"
"$BASE/install/bin/ffmpeg.exe" -hide_banner -version | head -n 3
"$BASE/install/bin/ffmpeg.exe" -hide_banner -encoders | grep -E 'h264_mf|libsvtav1|libopenh264|libx264' || true
