VidoByte Smart Video Compressor 0.3.4
Third-party build/source offer - draft, 2026-10-21

This file accompanies custom FFmpeg 9.0.2 and its dynamically linked codec/runtime libraries.
These materials are outside the installed MSIX package to avoid triggering the Microsoft
package scanner on source archives. They must be hosted and linked publicly before release.

Source of FFmpeg 9.0.2 (unmodified):
  https://ffmpeg.org/releases/ffmpeg-9.0.2.tar.xz
Build script on developer machine:
  D:\VidoByte\StoreMF\build_ffmpeg_custom.sh
Exact configuration:
  --disable-gpl --disable-nonfree --enable-version3 --disable-libopenh264
  --disable-libx264 --disable-libx265 --disable-autodetect --enable-libsvtav1
  --enable-libdav1d --enable-mediafoundation --enable-d3d11va
  --disable-ffplay --disable-doc --disable-debug --enable-static --disable-shared
MSYS2 UCRT64 GCC 16.2.0; SVT-AV1 4.2.0; dav1d 1.5.4.
FFmpeg, dav1d, SVT-AV1, GCC runtime, libwinpthread license texts shipped in MSIX under ThirdParty/.

Sources of external codec dependencies:
  https://code.videolan.org/videolan/dav1d
  https://gitlab.com/AOMediaCodec/SVT-AV1
Build and MSYS2 packages:
  https://packages.msys2.org/
  https://www.msys2.org/

IMPORTANT: the FFmpeg source archive and current build script are on the development PC,
not yet on a public source hosting URL. Do not publish VidoByte until a stable corresponding-source
offer, all relevant third-party notices, and codec patent/licensing review are completed.

Contact for source requests: lebao1462@gmail.com
